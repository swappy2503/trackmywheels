<?php
if(isset($_POST['submit']))
{
     echo "this is post request"
}
?>

<?php
//define("DB_HOST", "localhost");
define("DB_HOST", "192.168.0.100");
//define("DB_USER", "root");
define("DB_USER", "trackmyw_root");
define("DB_PASS", "root");
//define("DB_NAME", "db_exam");
define("DB_NAME", "trackmyw_db_exam");
